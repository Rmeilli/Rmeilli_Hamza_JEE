package ma.enset.hopitale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HopitaleApplicationTests {

    @Test
    void contextLoads() {
    }

}

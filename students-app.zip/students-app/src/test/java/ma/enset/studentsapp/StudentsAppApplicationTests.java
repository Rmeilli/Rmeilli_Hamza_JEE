package ma.enset.studentsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
